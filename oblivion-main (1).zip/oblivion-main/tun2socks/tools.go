//go:build tools
// +build tools

package tun2socks

import (
	_ "golang.org/x/mobile/bind"
	_ "golang.org/x/mobile/cmd/gomobile"
)
