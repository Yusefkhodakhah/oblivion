package org.bepass.oblivion.interfaces;

public interface SheetsCallBack {
    void onSheetClosed();
}
