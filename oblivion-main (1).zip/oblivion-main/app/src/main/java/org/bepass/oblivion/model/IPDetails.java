package org.bepass.oblivion.model;

public class IPDetails {
    public String ip;
    public String country;
    public String flag;
}
